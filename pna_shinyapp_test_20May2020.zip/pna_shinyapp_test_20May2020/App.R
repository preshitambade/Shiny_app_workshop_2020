# Shiny App Tutorial
# Preshit Ambade
# Original session by : Alise Ponsero
# Date: 20 May 2020

# Check Tidytuesday page for interesting datasets

# Create a minimum functioning App
#library(shiny)
# ??fuidpage()
library(shiny)
library(tidyverse)


# load ramen Ratings dataset
ramen_ratings <- readr::read_csv("ramen_dataset.csv")

# data should be loaded before ui and server code.
# Also, keep note that the data will not appear in the environment.
# But check the console to know if dataset is parsed or not


# get list of countries in dataset
country_list<- ramen_ratings %>% select(country) %>% unique()  
# this is loaded for dropdown menue of selecting the countries


#####################
# user interface (ui)
#####################

ui <- fluidPage( 
    # ----------------------------------
    h1("Best Ramens in the world", align = "center"),
    p("Explore the best ramens in the world, recommended by the users themselves! In this tab, you can 
                select your favorite ramen style and the country of fabrication. The table below display the best three 
                ramens for this selection!"),
    HTML('<center><img src="1200px-Shoyu_Ramen.jpg" width="100%"></center>'), # this adds image using html function from www folder
    # remember the image containing folder must be named as "www" always.
    br('<br/>'), # this adds space after the image
    # ----------------------------------
    sidebarLayout(fluid=TRUE,      # to include sidebar panel
                  sidebarPanel(
                    # adding widget for user inputs # following code creates drop down menue for user selection
                    selectInput("style", label="Select the ramen style:", # style = hidden name of input, label= is displayed above the dropdown
                                c("Pack" = "Pack", # these are the arguments specifics for the drop down
                                  "Bowl" = "Bowl",
                                  "Cup" = "Cup"), 
                                selected = "Cup",  # this allows the default selection is "Cup"
                                multiple= TRUE),  # this allows user to select multiple categories
                    
                    # add country drop-down
                    selectInput("country", label="Select the country of fabrication:",  # this adds country dropdown list from country data file
                                country_list, 
                                selected = "Japan",  # default is Japan
                                multiple= FALSE),  # multiple selection is not allowed
                    
                    # add radio button
                    radioButtons("pType", label="Choose View:",
                                 list("Barchart", "Boxplot"))
                  ),
                  mainPanel(
                    h3(textOutput("toptitle"), align = "left"), # h3 = html tag in shiny. this top title is used in server function
                    tableOutput("top3"),  # this specifies where we want to display our plots
                    conditionalPanel('input.pType=="Barchart"', plotOutput("barplot")), # conditional panel function here gives option to display either bar or box plot
                    # pay attention here we are using "." and not "$" unlike the regular R
                    conditionalPanel('input.pType=="Boxplot"', plotOutput("boxplot")),   # conditional panel function here gives option to display either bar or box plot        
                    ), # end main panel
    ),
    # ----------------------------------
    includeHTML("footer.html")   # another way to include html file 
  ) # end fluidpage panel
  

# visit widget gallery at ["https://shiny.rstudio.com/gallery/widget-gallery.html"]
# to have a look at different available widgets


#################
# server function
#################
#server <- function(input, output) {}  # this is empty server function


server <- function(input, output) {
  # Title main area
  # ----------------------------------
  output$toptitle <- renderText({    # we want to render text as a top title of the page which we have defined in UI. other options renderPlot, renderTable
    paste("Best ramens in ", input$country)  #input$country = uses selected country in the UI as input
    })
    
  # ----------------------------------
  # Reactive elements
  display_dataset <- reactive({
    ramen_ratings %>% filter(style %in% input$style & country == input$country) 
    # reactive elements helps to avoid repetition of codes which are commented out in table, barplot and boxplot output code chunk
  })
  
  
  # ----------------------------------
    # Table output
    output$top3 <- renderTable({  # this gives data in table format for the selected country
      #display_dataset <- ramen_ratings %>% filter(style %in% input$style & country == input$country)
      display_dataset() %>% arrange(desc(stars, review_number)) %>% slice(1:3) %>% select(-continent, -review_number)
      # parenthesis after  "display_dataset" indicates it is a reactive element
    })
    
    # ----------------------------------
    # Plot outputs
    output$barplot <- renderPlot({   # this gives data in bar plot format for the selected country
      #display_dataset <- ramen_ratings %>% filter(style %in% input$style & country == input$country)
      
      display_dataset() %>%  ggplot(aes(x=stars, fill=style)) +  # parenthesis after  "display_dataset" indicates it is a reactive element
        geom_histogram(color="black",binwidth = 1)+
        scale_x_continuous(breaks = c(0, 1, 2, 3, 4, 5), limits = c(-1,6))+
        ggtitle("Ramens Ratings") +
        ylab("Number of Ramens")+
        xlab("Average Ratings")+
        theme_minimal(base_size = 13)
    })
    
    output$boxplot <- renderPlot({    # this gives data in box plot format for the selected country
      #display_dataset <- ramen_ratings %>% filter(style %in% input$style & country == input$country)
      
      display_dataset() %>% ggplot(aes(x=style, y=stars, color=style)) +  # parenthesis after  "display_dataset" indicates it is a reactive element
        geom_boxplot() +
        ggtitle("Ramens Ratings") +
        ylab("Average Ratings") +
        xlab("Style of Ramen") +
        theme_minimal(base_size = 13) 
    
    })
}

# above sequencing is important. Render element should be defined before any other output

#################
# running the app
#################
shinyApp(ui = ui, server = server)


#####################
# hosting on shiny.io
#####################
#install.packages('rsconnect')
#library(rsconnect)
#rsconnect::setAccountInfo(name='preshitambade', token='E01EE292BD5061C35689BDC045F8CA29', secret='<secret>')
# run these three lines to authorize the computer for upload. This is only one-time process. 
# check getting started page for shinyapps.io


deployApp() # or use publish application option on top of r-script page, follow the steps to push the application on shinyapp.io



###############################
# More information on ShinyApp
###############################

# Get inspiration from the Shiny Gallery
# https://shiny.rstudio.com/gallery/ 
#   
#   Shiny provides good tutorials (video and articles)
# https://shiny.rstudio.com/tutorial/
#   
#   A great (and very long) blog post that covers basically everything about shiny
# http://zevross.com/blog/2016/04/19/r-powered-web-applications-with-shiny-a-tutorial-and-cheat-sheet-with-40-example-apps/#eventreactive-used-to-prevent-unwanted-reactions-in-a-reactive-function
#   